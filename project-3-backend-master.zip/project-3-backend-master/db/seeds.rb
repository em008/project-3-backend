

#User.create(username: "admin", password: "password")

# Budget.create(name: "business", amount: 100000, user_id: 1)
# Budget.create(name: "private", amount: 10000000, user_id: 1)

# Expense.create(amount: 25000, category: "food", date: "2020-08-24", budget_id: 2)
Expense.create(amount: 10000, category: "other", date: "2020-08-24", budget_id: 2)
Expense.create(amount: 50000, category: "housing", date: "2020-08-24", budget_id: 3)




